
<?php $__env->startSection('content'); ?>
    <h1>About Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime temporibus omnis magni placeat 
        laudantium amet necessitatibus recusandae aspernatur iure provident velit labore, laborum,
         in beatae libero rem ea veniam aperiam.</p>
         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <h4><?php echo e($u['name']); ?> - <?php echo e($u['city']); ?> - <?php echo e($u['phone']); ?>

            -<a class="link" href="<?php echo e(route('view.user',$id)); ?>">show</a>
            </h4>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidbar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidbar'); ?>
    <p class="p">Lorem, hi rakibul !</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\example-app\resources\views/about.blade.php ENDPATH**/ ?>