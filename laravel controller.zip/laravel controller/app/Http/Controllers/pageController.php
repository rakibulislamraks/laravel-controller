<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pageController extends Controller
{
    public function showUser(){
        return view('welcome');
    }
    public function showBlog(){
        return view('blog');
    }
    public function showAbout(){
        return view('posts');
    }
}
