<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\pageController;

// function gateUser(){
//     return [
//         1 => ['name'=>'rakibul islam','city'=>'dhaka','phone'=>'0181984984'],
//         2 => ['name'=>'ariful islam','city'=>'dhaka','phone'=>'0181984984'],
//         3 => ['name'=>'sakil islam','city'=>'dhaka','phone'=>'0181984984'],
//         4 => ['name'=>'mujibul islam','city'=>'dhaka','phone'=>'0181984984'],
//         5 => ['name'=>'rashidul islam','city'=>'dhaka','phone'=>'0181984984'],
//     ];
// }

// Route::get('/', function () {
//     return view('welcome');
// });

// // Route::get('/post', function () {
// //     return view('posts');
// // });

// Route::get('/news', function () {
//     return view('news');
// });
// Route::get('/about', function () {
//    $names = gateUser();
//     return view('about',['user'=>$names]);
// });

// Route::prefix('page')->group(function(){
//     Route::get('/aboutUs', function () {
//         return view('about');
//     })->Name('about');
    
//     Route::get('/postpage', function () {
//         return view('posts');
//     })->Name('post');
    
//     Route::get('/news', function () {
//         return view('news');
//     });
// });

// Route::fallback(function(){
//     return "<h1>Page Not Found</h1>";
// });

// Route::get('/rak/{id}', function (string $id) {
//     if($id){
//         return "<h1> Post Id: ". $id ." </h1>";
//     }else{
//         return "<h1>Id is Not found</h1>";

//     }
// })->whereIn('id',['move','song']);

// Route::view('rak','/posts');


// Route::redirect('/news','/new');

// Route::get('/user/{id}', function ($id) {
//     $users = gateUser();
//     abort_if(!isset($users[$id]),404);
//     $user = $users[$id];
//     return view('news',['id'=> $user]);
// })->name('view.user');



Route::controller(pageController::class)->group(function(){
    Route::get('/','showUser');
    Route::get('/blog','showBlog')->name('blog');
    Route::get('/posts','showAbout');
});