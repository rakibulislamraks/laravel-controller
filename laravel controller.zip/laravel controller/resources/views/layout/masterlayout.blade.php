<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title','rakaVai')</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <h1>Header</h1>
    
</header>

<div class="container">
    <div class="sidebar">
        
        @section('sidbar')
        <h2>Sidebar</h2>
        <p>This is the sidebar content.</p>
        <a href="/about">About</a>
        <a href="/news">News</a>
        <a href="/post">Post</a>
        <a href="/">Home</a>
        @show
    </div>
    <div class="content">
        @hasSection ('content')
            @yield('content')
                
        @else
            <h2>No content found!</h2>
        @endif
      </div>
</div>

<footer>
    <p>Footer</p>
</footer>

</body>
</html>
