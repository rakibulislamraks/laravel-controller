{{-- @extends('layout.masterlayout')
{{-- @section('content')
    <h1>News Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime temporibus omnis magni placeat laudantium amet necessitatibus recusandae aspernatur iure provident velit labore, laborum, in beatae libero rem ea veniam aperiam.</p>
@endsection --}}
@section('title')
    News
@endsection 
<h1>User Details</h1>
<h4>Name: {{ $id['name']}}</h4>
<h4>city: {{ $id['city']}}</h4>
<h4>phone: {{ $id['phone']}}</h4>