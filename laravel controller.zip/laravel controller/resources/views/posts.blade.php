@extends('layout.masterlayout')

@section('content')
    <h1>post Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime temporibus omnis magni placeat laudantium amet necessitatibus recusandae aspernatur iure provident velit labore, laborum, in beatae libero rem ea veniam aperiam.</p>
@endsection
@section('title')
    Post
@endsection

